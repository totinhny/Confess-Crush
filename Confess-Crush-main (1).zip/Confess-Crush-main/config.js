const CONFIG = {
    titleWeb: "Tỏ tình crush<33",
    introTitle: 'Crush của tui ><',
    introDesc: `Trái đất vốn lạ thường
    Mà sao em cứ đi nhầm đường
    Lạc vào tim anh lẻ loi
    Đằng sau chữ yêu đây là thương`,
    btnIntro: '^^HiHi^^',
    title: 'Cậu có iu có thương tớ hông:333 ?',
    desc: 'Cậu thoát ra là yew tớ đấy nhá <333 ',
    btnYes: 'Yew cậu nhìu lắm<333',
    btnNo: 'Không nha :3',
    question: 'Trên thế giới hơn 7 tỉ người mà sao bạn lại yêu mình <3',
    btnReply: 'Gửi cho bạn <3',
    reply: 'Vì cậu rất cute phô mai que nên tớ rất yew cậu>.<',
    mess: 'Mình biết mà 🥰. Yêu cậu nhiều lắm:3 😘😘',
    messDesc: 'Kể từ bây h, cậu sẽ là của tớ<333333.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://d1ozsoeh4648m4.cloudfront.net/861/083/264/-449996982-1sjl2lk-js7koab5qpt64lk/original/file.jpg' //link mess của các bạn. VD: https://m.me/nam.nodemy
}
